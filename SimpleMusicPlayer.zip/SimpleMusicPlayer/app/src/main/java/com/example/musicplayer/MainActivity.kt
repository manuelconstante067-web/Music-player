package com.example.musicplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class Track(val uri: Uri, val title: String, val artist: String)

    private val tracks = ArrayList<Track>()
    private var player: MediaPlayer? = null
    private var index = -1
    private var userSeeking = false
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var listView: ListView
    private lateinit var nowPlaying: TextView
    private lateinit var timeText: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var btnPlayPause: Button

    private val skipMs = 10_000

    // Updates the seek bar and time label twice a second.
    private val ticker = object : Runnable {
        override fun run() {
            player?.let { p ->
                try {
                    if (!userSeeking) {
                        seekBar.max = p.duration
                        seekBar.progress = p.currentPosition
                    }
                    timeText.text = "${fmt(p.currentPosition)} / ${fmt(p.duration)}"
                } catch (_: IllegalStateException) {
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.songList)
        nowPlaying = findViewById(R.id.nowPlaying)
        timeText = findViewById(R.id.timeText)
        seekBar = findViewById(R.id.seekBar)
        btnPlayPause = findViewById(R.id.btnPlayPause)

        btnPlayPause.setOnClickListener { togglePlayPause() }
        findViewById<Button>(R.id.btnRewind).setOnClickListener { seekBy(-skipMs) }
        findViewById<Button>(R.id.btnForward).setOnClickListener { seekBy(skipMs) }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { if (tracks.isNotEmpty()) play(index - 1) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { if (tracks.isNotEmpty()) play(index + 1) }

        listView.setOnItemClickListener { _, _, position, _ -> play(position) }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                player?.seekTo(seekBar.progress)
                userSeeking = false
            }
        })

        if (hasAudioPermission()) {
            loadTracks()
        } else {
            requestPermissions(arrayOf(audioPermission()), REQUEST_AUDIO)
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }

    // ---------- Permissions ----------

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission(): Boolean =
        checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadTracks()
            } else {
                nowPlaying.text = "Permission denied. Allow access to music in Settings > Apps."
            }
        }
    }

    // ---------- Library ----------

    private fun loadTracks() {
        tracks.clear()

        val collection: Uri = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )

        // All audio files, except ringtones, notification and alarm sounds.
        val selection = "${MediaStore.Audio.Media.IS_RINGTONE}=0 AND " +
                "${MediaStore.Audio.Media.IS_NOTIFICATION}=0 AND " +
                "${MediaStore.Audio.Media.IS_ALARM}=0"

        contentResolver.query(
            collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val artist = c.getString(artistCol)
                tracks.add(
                    Track(
                        ContentUris.withAppendedId(collection, id),
                        c.getString(titleCol) ?: "Unknown title",
                        if (artist.isNullOrBlank() || artist == "<unknown>") "Unknown artist" else artist
                    )
                )
            }
        }

        // simple_list_item_2 has two lines: title on top, artist below.
        listView.adapter = object : ArrayAdapter<String>(
            this, android.R.layout.simple_list_item_2, android.R.id.text1,
            tracks.map { it.title }
        ) {
            override fun getView(
                position: Int,
                convertView: android.view.View?,
                parent: android.view.ViewGroup
            ): android.view.View {
                val v = super.getView(position, convertView, parent)
                v.findViewById<TextView>(android.R.id.text2).text = tracks[position].artist
                return v
            }
        }

        nowPlaying.text = if (tracks.isEmpty()) "No music found on this phone"
        else "${tracks.size} songs found. Tap one to play."
    }

    // ---------- Playback ----------

    private fun play(i: Int) {
        if (tracks.isEmpty()) return
        index = ((i % tracks.size) + tracks.size) % tracks.size
        val track = tracks[index]

        player?.release()
        player = null

        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(applicationContext, track.uri)
            p.prepare()
            p.setOnCompletionListener { play(index + 1) }
            p.start()
            player = p
        } catch (e: Exception) {
            Toast.makeText(this, "Can't play: ${track.title}", Toast.LENGTH_SHORT).show()
            btnPlayPause.text = "▶"
            return
        }

        nowPlaying.text = "${track.title}\n${track.artist}"
        btnPlayPause.text = "⏸"
        listView.setItemChecked(index, true)
        listView.smoothScrollToPosition(index)
    }

    private fun togglePlayPause() {
        val p = player
        if (p == null) {
            if (tracks.isNotEmpty()) play(if (index >= 0) index else 0)
            return
        }
        if (p.isPlaying) {
            p.pause()
            btnPlayPause.text = "▶"
        } else {
            p.start()
            btnPlayPause.text = "⏸"
        }
    }

    private fun seekBy(deltaMs: Int) {
        val p = player ?: return
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0, p.duration))
    }

    private fun fmt(ms: Int): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    companion object {
        private const val REQUEST_AUDIO = 1
    }
}
